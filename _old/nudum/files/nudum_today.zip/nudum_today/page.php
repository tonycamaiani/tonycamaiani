<?php get_header(); ?>

	<?php if (have_posts()) : ?>
	
		<?php while (have_posts()) : the_post(); ?>
					
			<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h1 class="page_title"><?php the_title(); ?></h1>
				<div class="content">
					<?php the_content(); ?>
				</div>

				<?php edit_post_link('Edit this post', '<p class="edit">', '</p>'); ?>

			</div>

		<?php endwhile; ?>

	<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>