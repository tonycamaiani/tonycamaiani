<!--
Theme: Nudum Today - a clean and empty theme for Wordpress Developers  
Original Author: Tony Camaiani
URL: http://tony.camaiani.it
-->
<!doctype html>  

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ --> 
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>">

  <title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
  <meta name="description" content="<?php bloginfo('tagline'); ?>">
  <meta name="author" content="Tony Camaiani">

  <!-- Replace favicon.ico & apple-touch-icon.png, if you move them to the root of your domain you can delete these references -->
  <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/ico/favicon.ico">
  <link rel="apple-touch-icon" href="<?php bloginfo('template_directory'); ?>/images/ico/apple-touch-icon.png">


  <!-- CSS -->
  <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css?v=1">

  <!-- Uncomment if you are specifically targeting less enabled mobile browsers
  <link rel="stylesheet" media="handheld" href="<?php bloginfo('template_directory'); ?>/css/handheld.css?v=1">  -->
 
  <!-- All JavaScript at the bottom, except for Modernizr which enables HTML5 elements & feature detects -->
 <script src="<?php bloginfo('template_directory'); ?>/js/libs/modernizr-1.6.min.js"></script>

  <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
  <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

  <div id="container">
    <div id="header">
				<?php $heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
				<<?php echo $heading_tag; ?> id="site-title">
					<a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				</<?php echo $heading_tag; ?>>
				<div id="site-description"><?php bloginfo( 'description' ); ?></div>
    </div>

	<div id="top_nav">
		<ul>
			<?php wp_list_pages('title_li=');?>
		</ul>
	</div>
    
    <div id="content">
