<?php get_header(); ?>

	<h1 class="page_title">Search results for <?php echo get_search_query(); ?> </h1>
	
	<?php if (have_posts()) : ?>
	
		<?php while (have_posts()) : the_post(); ?>
					
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h2 class="post_title"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				posted by <b><?php echo get_the_author(); ?></b> on
				<div class="datetime"><?php the_time('l, F jS, Y') ?></div>
				<div class="excerpt">
					<?php the_excerpt('Read the rest of this entry &raquo;'); ?>
				</div>
				<ul class="post_nav">
					<li>In: <?php the_category(', '); ?></li>
					<?php if (has_tag()) : ?><li><?php the_tags(' Tagged with ', ', ', ''); ?></li><?php endif; ?>
					<?php if (comments_open()) : ?><li><?php comments_popup_link('Add a comment', '1 comment', '% comments'); ?></li><?php endif; ?>
					<?php edit_post_link('Edit this post', '<li>', '</li>'); ?>
				</ul>
			</div>

		<?php endwhile; ?>

		
		<?php if ( $wp_query->max_num_pages > 1 ) : ?>
			<ul id="pagination">
				<li class="nav-previous"><?php next_posts_link('Older Entries »'); ?></li>
				<li class="nav-next"><?php previous_posts_link('« Newer Entries'); ?></li>
			</ul>
		<?php endif; ?>

	<?php else : ?>
			<div class="search nothing-found" role="main">
				<h2 class="title">Nothing Found</h2>
				<p>Sorry, but nothing matched your search criteria. Maybe you could try searching again  with some different keywords.</p>
				<?php get_search_form(); ?>
			</div>
	<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>