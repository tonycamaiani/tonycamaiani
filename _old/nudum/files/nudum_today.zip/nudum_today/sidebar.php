	<div id="sidebar" role="complementary">
		<ul id="side_nav">
			<?php wp_list_categories('title_li=');?>
		</ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
		<?php endif; ?>
	</div>


