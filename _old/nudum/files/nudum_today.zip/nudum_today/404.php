<?php get_header(); ?>

			<div class="error404 not-found" role="main">
				<h2 class="page_title">Not Found</h2>
				<p>The page you requested could not be found. Maybe you could try searching.</p>
				<?php get_search_form(); ?>
			</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>