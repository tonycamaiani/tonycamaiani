<?php get_header(); ?>

	<?php if (have_posts()) : ?>
	
		<?php while (have_posts()) : the_post(); ?>
					
			<ul id="above_nav">
				<li class="nav-previous"><?php next_post_link(); ?></li>
				<li class="nav-next"><?php previous_post_link(); ?></li>
			</ul>


			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<h1 class="post_title"><?php the_title(); ?></h1>
				<div class="datetime"><?php the_time('l, F jS, Y') ?></div>

				<div class="content">
					<?php the_content(); ?>
				</div>

				<ul class="post_nav">
					<li>Posted in: <?php the_category(', '); ?></li>
					<?php if (has_tag()) : ?><li><?php the_tags(' Tagged with ', ', ', ''); ?></li><?php endif; ?>
					<?php edit_post_link('Edit this post', '<li>', '</li>'); ?>
				</ul>

			<?php comments_template( '', true ); ?>

			</div>

		<?php endwhile; ?>						
	<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>