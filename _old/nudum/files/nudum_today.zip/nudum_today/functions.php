<?php
// Registering the first widget enabled sidebar element
// for more info: http://codex.wordpress.org/Function_Reference/register_sidebar
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
        'before_title' => '<h3 class="title">',
        'after_title' => '</h3>',
    ));

// Example of adding a custom post type 
// change the parameters and uncomment to make it yours
// for more info: http://codex.wordpress.org/Function_Reference/register_post_type
/* --> remove this line to make it work
add_action('init', 'alt_post_type');
function alt_post_type() {
  $labels = array(
    'name' => _x('Alternate posts', 'post type general name'),
    'singular_name' => _x('A Post', 'post type singular name'),
    'add_new' => _x('Add New', 'alternate_posts'),
    'add_new_item' => __('Add New Alt')
  );
 
 $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'hierarchical' => true,
    'menu_position' => null,
	'supports' => array(
	'title',
	'editor',
	'excerpt',
	'trackbacks',
	'custom-fields',
	'comments',
	'revisions',
	'thumbnail',
	'author',
	'page-attributes',)
	); 
 
  register_post_type('alternate_posts',$args);
}
remove this line to make it work --> */

// Example of adding a custom taxonomy 
// change the parameters and uncomment to make it yours
// for more info: http://codex.wordpress.org/Function_Reference/register_taxonomy
/* --> remove this line to make it work
add_action( 'init', 'build_taxonomies', 0 );

function build_taxonomies() {
    register_taxonomy( 'event', 'alternate_posts', array( 'hierarchical' => true, 'label' => 'Event', 'query_var' => true, 'rewrite' => true ));
	}
remove this line to make it work --> */


//
// callback for wp_list_comments() for displaying the comments.
//
function mytheme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <div <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
      <div class="comment-author vcard">
         <?php echo get_avatar($comment,$size='48',$default='<path_to_url>' ); ?>
         <?php printf(__('Comment by <cite class="fn">%s</cite>'), get_comment_author_link()) ?>
		at <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a>
      </div>

      <?php if ($comment->comment_approved == '0') : ?>
         <p class="awaiting"><em><?php _e('Your comment is awaiting moderation.') ?></em></p>
      <?php endif; ?>

		<div class="comment_content">
	      <?php comment_text() ?>
		</div>

      <div class="reply">
		<?php edit_comment_link(__('Edit | '),'  ','') ?>
		<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
      </div>
     </div>
<?php
        }
?>