<?php get_header(); ?>
	
	<?php if (have_posts()) : ?>

	    <?php if (is_category()) { ?>
	    	<h1 class="page_title"><?php single_cat_title(); ?></h1>
	    <?php } elseif( is_tag() ) { ?>
	    	<h1 class="page_title">Posts Tagged &#8216;<?php single_tag_title(); ?>&#8217;</h1>
	    <?php } elseif (is_day()) { ?>
	    	<h1 class="page_title">Archive for <?php the_time('F jS, Y'); ?></h1>
	    <?php } elseif (is_month()) { ?>
	    	<h1 class="page_title">Archive for <?php the_time('F, Y'); ?></h1>
	    <?php } elseif (is_year()) { ?>
	    	<h1 class="page_title">Archive for <?php the_time('Y'); ?></h1>
	    <?php } elseif (is_author()) { ?>
	    	<h1 class="page_title">Author Archive</h1>
	    <?php } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
	    	<h1 class="page_title">Blog Archives</h1>
	    <?php } ?>                                   

	
		<?php while (have_posts()) : the_post(); ?>
					
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header>
					<h2 class="post_title"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
					posted by <b><?php echo get_the_author(); ?></b> on
					<time datetime="<?php the_time('Y-m-d') ?>" pubdate><?php the_time('l, F jS, Y') ?></time>
				</header>
				<div class="excerpt">
					<?php the_excerpt('Read the rest of this entry &raquo;'); ?>
				</div>
				<footer>
					<nav>
						<ul>
							<li>In: <?php the_category(', '); ?></li>
							<?php if (has_tag()) : ?><li><?php the_tags(' Tagged with ', ', ', ''); ?></li><?php endif; ?>
							<?php if (comments_open()) : ?><li><?php comments_popup_link('Add a comment', '1 comment', '% comments'); ?></li><?php endif; ?>
							<?php edit_post_link('Edit this post', '<li>', '</li>'); ?>
						</ul>
					</nav>
				</footer>

			</article>

		<?php endwhile; ?>

		
		<?php if ( $wp_query->max_num_pages > 1 ) : ?>
		<nav id="pagination">
				<ul>
					<li class="nav-previous"><?php next_posts_link('Older Entries »'); ?></li>
					<li class="nav-next"><?php previous_posts_link('« Newer Entries'); ?></li>
				</ul>
		</nav>
		<?php endif; ?>

	<?php else : ?>
				<article class="archive nothing-found" role="main">
				<h2 class="title">Nothing Found</h2>
				<p>But maybe you could try searching.</p>
				<?php get_search_form(); ?>
			</article>
	<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>