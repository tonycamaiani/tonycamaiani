	<aside id="sidebar" role="complementary">
		<nav>
			<ul>
				<?php wp_list_categories('title_li=');?>
			</ul>
		</nav>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
		<?php endif; ?>
	</aside>


