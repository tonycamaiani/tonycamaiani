<?php get_header(); ?>

	<?php if (have_posts()) : ?>
	
		<?php while (have_posts()) : the_post(); ?>
					
		<nav id="above">
				<ul>
					<li class="nav-previous"><?php next_post_link(); ?></li>
					<li class="nav-next"><?php previous_post_link(); ?></li>
				</ul>
		</nav>


			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header>
					<h1 class="post_title"><?php the_title(); ?></h1>
					<time datetime="<?php the_time('Y-m-d') ?>" pubdate><?php the_time('l, F jS, Y') ?></time>
				</header>
				<div class="content">
					<?php the_content(); ?>
				</div>
				<footer>
					<nav>
						<ul>
							<li>Posted in: <?php the_category(', '); ?></li>
							<?php if (has_tag()) : ?><li><?php the_tags(' Tagged with ', ', ', ''); ?></li><?php endif; ?>
							<?php edit_post_link('Edit this post', '<li>', '</li>'); ?>
						</ul>
					</nav>
				</footer>


			<?php comments_template( '', true ); ?>

			</article>

		<?php endwhile; ?>						
	<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>