<!--
Theme: Wordpress clean theme based on Html5 Boilerplate
Original Author: Tony Camaiani
URL: http://tony.camaiani.it
This theme is based on the http://html5boilerplate.com project
-->
<!doctype html>  

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ --> 
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">

  <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
       Remove this if you use the .htaccess -->
  <!--[if IE ]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <![endif]-->
  <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>">


  <title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
  <meta name="description" content="<?php bloginfo('tagline'); ?>">
  <meta name="author" content="Tony Camaiani">

  <!--  Mobile viewport optimized: j.mp/bplateviewport -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Replace favicon.ico & apple-touch-icon.png, if you move them to the root of your domain you can delete these references -->
  <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/ico/favicon.ico">
  <link rel="apple-touch-icon" href="<?php bloginfo('template_directory'); ?>/images/ico/apple-touch-icon.png">


  <!-- CSS -->
  <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css?v=1">

  <!-- Uncomment if you are specifically targeting less enabled mobile browsers
  <link rel="stylesheet" media="handheld" href="<?php bloginfo('template_directory'); ?>/css/handheld.css?v=1">  -->

 
  <!-- All JavaScript at the bottom, except for Modernizr which enables HTML5 elements & feature detects -->
  <script src="<?php bloginfo('template_directory'); ?>/js/libs/modernizr-1.6.min.js"></script>

  <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
  <?php wp_head(); ?>


</head>

<body <?php body_class(); ?>>


  <div id="container">
    <header>
				<?php $heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
				<<?php echo $heading_tag; ?> id="site-title">
					<a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				</<?php echo $heading_tag; ?>>
				<div id="site-description"><?php bloginfo( 'description' ); ?></div>
    </header>

	<nav>
		<ul>
			<?php wp_list_pages('title_li=');?>
		</ul>
	</nav>
    
    <div id="content">
